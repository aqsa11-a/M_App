plugins {
    id("com.android.application")
    id("kotlin-android")
}

android {
    namespace = "com.example.sqlite"  // Make sure it's correct
    compileSdk = 34  // Make sure this is a valid number

    defaultConfig {
        applicationId = "com.example.sqlite"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}
